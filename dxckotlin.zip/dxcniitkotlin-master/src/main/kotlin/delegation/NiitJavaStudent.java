package delegation;

public class NiitJavaStudent {
  String name;
  int age;

  public NiitJavaStudent(String name, int age) {
    this.name = name;
    this.age = age;
  }
}
