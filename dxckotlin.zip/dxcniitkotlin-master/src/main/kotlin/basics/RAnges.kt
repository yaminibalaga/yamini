package basics

class RAnges {
}

fun main() {
    val x = 2;
    val y = 6
for ( x in 10 downTo  1 step 3) println(x)
   /* if(x in  3..y) {
        println(" x is in the range ")
    }
    else {
        println(" NOT in the range ")
    }*/

    //write a function with a switch case
    //let that function accept a value and print
    //if the given no is in the range 1 to 10 print its in  10s
    // if its b/w 100 to 99 print its in 100's
    //if the given no is in b/w 999 and 9999 then print its in 1000s
}