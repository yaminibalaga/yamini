package classes

class Subclass : SealedClass("name") {
}