package classes

 open class SealedClass(val name: String)
